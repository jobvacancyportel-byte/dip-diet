When project updates occur
- Check if README.md needs updates when adding new features or components
- Update the Features section when new functionality is added
- Modify Design Theme section if color scheme or styling changes
- Update Key Components list when new major components are created
- Revise Technology Stack if new libraries or frameworks are added
- Keep the README current and accurate to reflect the project's state