# Dip Diet - Ayurvedic Healing Website

## Project Overview
A bilingual (Hindi + English) Ayurvedic and natural healing website for "Dip Diet" - a personalized diet healing center.

## Features
- **Hero Section**: Bilingual introduction with call-to-action
- **About Section**: Information about Dip Diet's approach and expertise
- **Diseases Section**: Comprehensive list of treatable conditions
- **Consultation Form**: Online booking with payment integration
- **Feedback Section**: Patient testimonials and experience sharing
- **Footer**: Contact information and social media links

## Design Theme
- **Colors**: Ayurvedic Green (#4CAF50), Cream (#FFF8E1), Herbal Yellow (#FFC107)
- **Style**: Modern minimalist with natural healing elements
- **Typography**: Clean, readable fonts with proper hierarchy

## Key Components
- Bilingual content throughout (Hindi + English)
- Payment modal for ₹500 consultation fee
- WhatsApp integration for doctor consultation
- Responsive design for all devices
- Smooth animations and interactions

## Payment Flow
1. User fills consultation form
2. Payment modal appears (₹500 fee)
3. After payment, WhatsApp link opens with consultation details
4. Doctor receives patient information via WhatsApp

## Technology Stack
- React 18 with Babel
- TailwindCSS for styling
- Lucide icons
- Responsive design patterns